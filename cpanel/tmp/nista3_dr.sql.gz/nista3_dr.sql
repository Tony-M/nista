-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb1ubuntu0.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Авг 18 2009 г., 18:42
-- Версия сервера: 5.0.67
-- Версия PHP: 5.2.6-2ubuntu4.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `nista3_dr`
--

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_nista_blog`
--

CREATE TABLE IF NOT EXISTS `tbl_nista_blog` (
  `blog_id` int(10) unsigned NOT NULL auto_increment,
  `blog_owner_id` int(10) unsigned default NULL,
  `title` text NOT NULL,
  `text` text,
  `short_text` tinytext,
  `meta_keywords` text,
  `meta_description` text,
  `type` varchar(7) default NULL,
  `status` varchar(4) default 'wait',
  `creator_uid` int(10) unsigned NOT NULL,
  `creator_type` int(11) default NULL COMMENT 'nista_admin or nista_user',
  `sequence` int(11) NOT NULL,
  PRIMARY KEY  (`blog_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

--
-- Дамп данных таблицы `tbl_nista_blog`
--


-- --------------------------------------------------------

--
-- Структура таблицы `tbl_nista_config`
--

CREATE TABLE IF NOT EXISTS `tbl_nista_config` (
  `config_name` varchar(255) NOT NULL default '',
  `config_value` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `tbl_nista_config`
--

INSERT INTO `tbl_nista_config` (`config_name`, `config_value`) VALUES
('version', '.0.0'),
('access_log', 'on'),
('logger_log', 'on');

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_nista_data_structure`
--

CREATE TABLE IF NOT EXISTS `tbl_nista_data_structure` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `pid` int(11) unsigned NOT NULL,
  `category_id` int(3) unsigned NOT NULL,
  `ico` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `short_text` text NOT NULL,
  `text` longtext NOT NULL,
  `meta_keyword` text NOT NULL,
  `meta_description` text NOT NULL,
  `lang_id` varchar(2) NOT NULL,
  `status` varchar(5) NOT NULL default 'wait',
  `access_level` int(1) unsigned NOT NULL default '0',
  `penname` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL,
  `creator_uid` int(11) unsigned NOT NULL,
  `timestmp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `change_times` int(3) unsigned NOT NULL default '0',
  `sequence` int(6) unsigned NOT NULL,
  `template` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `modid` tinyint(10) NOT NULL default '0',
  `type` varchar(15) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Дамп данных таблицы `tbl_nista_data_structure`
--

INSERT INTO `tbl_nista_data_structure` (`id`, `pid`, `category_id`, `ico`, `title`, `short_text`, `text`, `meta_keyword`, `meta_description`, `lang_id`, `status`, `access_level`, `penname`, `date_created`, `creator_uid`, `timestmp`, `change_times`, `sequence`, `template`, `link`, `modid`, `type`) VALUES
(7, 5, 0, '', 'подраздел 1', '', 'подраздел', '', '', '', 'on', 0, '', '2009-06-25 20:15:02', 3, '2009-07-23 12:39:32', 0, 4, 'layout_test2.tpl', '/test2', 11, 'prt'),
(1, 1, 0, '', 'Корневой раздел сайта', '', '', '', '', '', 'on', 0, '', '2009-06-21 21:52:55', 3, '2009-07-17 16:50:52', 0, 1, '', '/', 11, 'prt'),
(5, 1, 0, '', 'раздел 1', '', 'текст раздела 1', 'ключи 1', 'описание 1', '', 'off', 0, '', '2009-06-25 20:14:55', 3, '2009-07-22 15:41:56', 0, 2, 'layout_test2.tpl', '/cataloggggg/test3', 11, 'prt'),
(6, 6, 0, '', 'Раздел 2', '', 'ываыва ыва ы', 'ыва ыв', 'а ыва ыв', '', 'wait', 0, 'ууууу', '2009-08-03 16:08:01', 3, '2009-08-03 16:08:01', 0, 3, 'layout_test1.tpl', '/test2/test5', 11, 'prt'),
(8, 9, 0, '', 'YНDDDYраздел 3', '', 'YYразд&lt;strong&gt;ел 3 для с&lt;/strong&gt;амых самых крутых&amp;nbsp;&lt;img height=&quot;128&quot; width=&quot;128&quot; src=&quot;/img/accessories_dictionary.png&quot; alt=&quot;accessories_dictionary.png&quot; /&gt;', 'YYк3', 'YYо3', '', 'wait', 2, 'ЙА АВТОР', '2009-06-25 20:10:36', 3, '2009-08-03 14:53:03', 0, 5, 'layout_test2.tpl', '/test2/index.php?data=8', 11, 'prt'),
(9, 7, 0, '', 'раздел 4', '', 'ляляля&amp;nbsp;', '', '', '', 'off', 0, '', '2009-06-25 16:44:59', 3, '2009-08-03 14:53:03', 0, 6, 'layout_test2.tpl', '/test2/index.php?data=9', 11, 'prt'),
(13, 5, 0, '', 'Статья 2', '', 'ывываыва ыв ыва ыва', 'ываыв', 'ываываыва', '', 'wait', 0, '', '2009-07-07 22:15:16', 3, '2009-07-09 18:11:35', 0, 8, '', '', 12, 'item'),
(14, 5, 0, '', 'Статья 3__', '', 'фывфывфывф_', 'ывф_', 'ывфывфыв_', '', 'on', 1, '__', '2009-07-09 17:54:41', 3, '2009-07-09 17:54:41', 0, 9, '', '', 12, 'item'),
(15, 5, 0, '', 'Статья 4', '', 'авпвапвапвап', 'вапва', 'пвапвап', '', 'wait', 0, '', '2009-07-07 23:25:51', 3, '2009-07-09 18:11:35', 0, 10, '', '', 12, 'item'),
(12, 5, 0, '', 'Статья 1', '', 'мегатекст статьи 1', 'ключик 1', 'опись 1', '', 'off', 1, 'йо', '2009-07-07 21:54:00', 3, '2009-07-09 18:08:48', 0, 7, '', '', 12, 'item'),
(16, 5, 0, '', 'Статья 5', '', 'ывыкаываыва 5 ыва ыва ываы', 'ыва ыва', 'ыва ыва ы', '', 'on', 0, '', '2009-07-08 19:19:06', 3, '2009-07-08 19:19:06', 0, 11, '', '', 12, 'item'),
(17, 5, 5, '', 'Статья 6', '', 'фыфывфы', 'фыв', 'фыв', '', 'wait', 0, '', '2009-07-08 19:21:44', 3, '2009-07-08 19:21:44', 0, 12, '', '', 12, 'item'),
(18, 6, 0, '', 'subpartition #1', '', 'asdfasdfadsfdfadf', '', '', '', 'wait', 0, '', '2009-08-03 16:09:24', 3, '2009-08-03 16:09:33', 0, 13, 'layout_test1.tpl', '/test2/test5/index.php?data=18', 11, 'prt');

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_nista_data_structure_category`
--

CREATE TABLE IF NOT EXISTS `tbl_nista_data_structure_category` (
  `id` int(3) unsigned NOT NULL auto_increment,
  `prt_id` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `tbl_nista_data_structure_category`
--

INSERT INTO `tbl_nista_data_structure_category` (`id`, `prt_id`, `title`) VALUES
(4, 1, 'категория 4ssd'),
(5, 5, 'кат 1 раз 1'),
(6, 5, 'кат 2 раз 2'),
(7, 7, 'кат 1 подраз 1');

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_nista_group`
--

CREATE TABLE IF NOT EXISTS `tbl_nista_group` (
  `gid` int(10) unsigned NOT NULL auto_increment,
  `modid` int(10) unsigned NOT NULL default '0',
  `group_name` varchar(255) NOT NULL default '',
  `group_description` text NOT NULL,
  `creatoruid` int(10) unsigned NOT NULL default '0',
  `status` varchar(4) NOT NULL default 'off',
  `date_created` datetime NOT NULL COMMENT 'дата добавления записи',
  `timestmp` timestamp NOT NULL default CURRENT_TIMESTAMP COMMENT 'время модификации',
  `type` varchar(15) NOT NULL default 'undefined' COMMENT 'тип группы (кто создал) system or user_defined',
  PRIMARY KEY  (`gid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `tbl_nista_group`
--

INSERT INTO `tbl_nista_group` (`gid`, `modid`, `group_name`, `group_description`, `creatoruid`, `status`, `date_created`, `timestmp`, `type`) VALUES
(1, 3, 'user_administrator', 'Администратор групп пользователей', 0, 'on', '2008-08-15 15:58:50', '2008-08-15 15:58:57', 'sys'),
(2, 3, 'user_self_edit', 'Изменение данных своей учётной записи', 0, 'on', '2008-08-22 15:29:13', '2008-08-22 15:29:25', 'sys'),
(3, 6, 'author_group', 'Создание, редактирование статей', 0, 'on', '2008-08-22 17:38:01', '2008-08-22 17:38:09', 'sys');

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_nista_group_user`
--

CREATE TABLE IF NOT EXISTS `tbl_nista_group_user` (
  `guid` int(10) unsigned NOT NULL auto_increment,
  `gid` int(10) unsigned NOT NULL default '0',
  `uid` int(10) unsigned NOT NULL default '0',
  `status` varchar(4) NOT NULL default 'off',
  `creatoruid` int(10) unsigned NOT NULL default '0',
  `date_created` date NOT NULL default '0000-00-00',
  `timestmp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

--
-- Дамп данных таблицы `tbl_nista_group_user`
--

INSERT INTO `tbl_nista_group_user` (`guid`, `gid`, `uid`, `status`, `creatoruid`, `date_created`, `timestmp`) VALUES
(22, 2, 14, 'on', 3, '2008-08-22', '2008-08-22 19:21:58');

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_nista_menu`
--

CREATE TABLE IF NOT EXISTS `tbl_nista_menu` (
  `menu_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `title` varchar(255) default NULL,
  `comment` varchar(255) NOT NULL default '',
  `text` text,
  `ico` varchar(255) default NULL,
  `status` varchar(4) default NULL,
  `sequence` int(5) default NULL,
  `link` text,
  `link_obj_id` int(10) unsigned default NULL,
  `link_mod_id` int(10) unsigned default NULL,
  `link_type` varchar(20) default NULL,
  `menu_type` varchar(10) default 'menu',
  PRIMARY KEY  (`menu_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=126 ;

--
-- Дамп данных таблицы `tbl_nista_menu`
--


-- --------------------------------------------------------

--
-- Структура таблицы `tbl_nista_mod`
--

CREATE TABLE IF NOT EXISTS `tbl_nista_mod` (
  `modid` tinyint(10) unsigned NOT NULL auto_increment,
  `mod_name` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `par` varchar(255) NOT NULL default '',
  `way` varchar(255) NOT NULL default '',
  `status` varchar(4) default 'off',
  `admin_uid` int(10) unsigned NOT NULL default '0',
  `timestmp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `public_class` varchar(255) default NULL,
  `private_class` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`modid`),
  UNIQUE KEY `modid` (`modid`),
  UNIQUE KEY `name` (`mod_name`),
  UNIQUE KEY `par` (`par`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Дамп данных таблицы `tbl_nista_mod`
--

INSERT INTO `tbl_nista_mod` (`modid`, `mod_name`, `description`, `par`, `way`, `status`, `admin_uid`, `timestmp`, `public_class`, `private_class`) VALUES
(1, 'core', 'Модуль главной страницы', 'ind', 'start_page.php', 'old', 0, '2009-05-31 22:24:33', NULL, ''),
(2, 'core_control', 'Модуль контрольной панели', 'set', 'control_pnl.php', 'old', 0, '2009-05-31 22:24:33', NULL, ''),
(3, 'core_account', 'Модуль осуществляет работу с учётными записями пользователей и их группами привилегий', 'u', 'account.php', 'old', 0, '2009-05-31 22:24:33', NULL, ''),
(12, 'item_manager', 'Модуль по работе со статьями сайта', 'item', 'mod/item_manager/index.php', 'on', 0, '2009-07-07 20:58:59', NULL, ''),
(8, 'set_mod', 'Модуль по работе с настройками сайта', 'site_settings', '../mod/set_mod/index.php', 'old', 0, '2009-05-31 22:24:33', NULL, 'mod/set_mod/lib/settings_manager_lib.php'),
(9, 'simple_gallery_mod', 'Модуль простой галереи изображений', 'sg', '../mod/simple_gallery_mod/index.php', 'old', 0, '2009-05-31 22:24:33', NULL, 'mod/simple_gallery_mod/lib/simple_gallery_mod_lib.php'),
(10, 'template_mod', 'Менеджер по работе с шаблонами. В основные функции модуля входит работа с элементами layout и Информационных зон.', 'tpl', 'mod/tpl_manager/index.php', 'on', 0, '2009-06-01 21:54:32', NULL, ''),
(11, 'partition_manager', 'Модуль по работе с разделами сайта', 'site', 'mod/partition_manager/index.php', 'on', 0, '2009-06-13 17:59:59', NULL, ''),
(13, 'menu_manager', 'модуль по работе с меню сайта', 'menu', 'mod/menu_manager/index.php', 'on', 0, '2009-08-18 18:40:35', NULL, '');

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_nista_object`
--

CREATE TABLE IF NOT EXISTS `tbl_nista_object` (
  `id_obj` int(10) unsigned NOT NULL auto_increment,
  `mod_id` int(10) unsigned default '0',
  `title` varchar(225) NOT NULL default '',
  `status` varchar(4) NOT NULL default '',
  PRIMARY KEY  (`id_obj`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `tbl_nista_object`
--

INSERT INTO `tbl_nista_object` (`id_obj`, `mod_id`, `title`, `status`) VALUES
(2, 4, 'part', 'on'),
(3, 5, 'menu', 'on'),
(4, 6, 'item', 'on'),
(5, 6, 'category', 'on'),
(6, 7, 'news', 'on'),
(7, 9, 'album', 'on');

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_nista_object_hierarchy`
--

CREATE TABLE IF NOT EXISTS `tbl_nista_object_hierarchy` (
  `level_id` int(10) NOT NULL auto_increment,
  `owner_id` int(10) unsigned NOT NULL default '0',
  `object_id` int(10) unsigned NOT NULL default '0',
  `mod_id` int(10) unsigned NOT NULL default '0',
  `type` varchar(20) NOT NULL default '',
  `status` varchar(4) default 'off',
  `timestmp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `sequence` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`level_id`),
  UNIQUE KEY `level_id` (`level_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=369 ;

--
-- Дамп данных таблицы `tbl_nista_object_hierarchy`
--

INSERT INTO `tbl_nista_object_hierarchy` (`level_id`, `owner_id`, `object_id`, `mod_id`, `type`, `status`, `timestmp`, `sequence`) VALUES
(1, 1, 1, 4, 'part', 'on', '2007-07-04 19:17:36', 1),
(318, 1, 37, 4, 'part', 'off', '2008-06-17 18:21:29', 2),
(319, 1, 38, 4, 'part', 'off', '2008-06-17 18:21:50', 3),
(320, 320, 58, 6, 'item', 'on', '2008-06-18 16:22:30', 4),
(321, 1, 320, 6, '#link', 'on', '2008-06-18 16:22:30', 5),
(322, 322, 59, 6, 'item', 'on', '2008-06-18 16:22:52', 6),
(323, 323, 60, 6, 'item', 'on', '2008-06-18 16:23:07', 7),
(324, 318, 323, 6, '#link', 'on', '2008-06-18 16:23:07', 8),
(325, 325, 61, 6, 'item', 'on', '2008-06-18 16:23:21', 9),
(326, 319, 325, 6, '#link', 'on', '2008-06-18 16:23:21', 10),
(339, 339, 70, 6, 'item', 'on', '2008-09-14 23:58:34', 11),
(342, 318, 39, 4, 'part', 'off', '2008-11-30 02:07:36', 12),
(365, 364, 0, 0, '#link', 'del', '2008-12-01 15:23:08', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_nista_privilages`
--

CREATE TABLE IF NOT EXISTS `tbl_nista_privilages` (
  `privid` int(10) unsigned NOT NULL auto_increment,
  `gid` int(10) unsigned NOT NULL default '0',
  `func_name` varchar(255) NOT NULL default '',
  `func_description` text NOT NULL,
  `rwx` varchar(3) NOT NULL default '000',
  `status` varchar(4) NOT NULL default 'off',
  `creatoruid` int(10) unsigned NOT NULL default '0',
  `date_created` datetime NOT NULL,
  `timestmp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `modid` int(10) unsigned NOT NULL default '0' COMMENT 'принадлежность привилегии модулю',
  PRIMARY KEY  (`privid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `tbl_nista_privilages`
--

INSERT INTO `tbl_nista_privilages` (`privid`, `gid`, `func_name`, `func_description`, `rwx`, `status`, `creatoruid`, `date_created`, `timestmp`, `modid`) VALUES
(1, 1, 'ls_users', 'Просмотр списка пользователей', '001', 'on', 0, '2008-08-15 16:00:21', '2008-08-15 16:00:26', 3),
(2, 1, 'mk_user', 'Создание пользоватеей', '001', 'on', 0, '2008-08-15 16:02:20', '2008-08-15 16:02:23', 3),
(3, 1, 'edit_user', 'Редактирование пользоватеьских записей', '001', 'on', 0, '2008-08-15 16:03:14', '2008-08-15 16:03:18', 3),
(4, 1, 'rm_user', 'Удаление пользоватеьских записей', '001', 'on', 0, '2008-08-15 16:03:14', '2008-08-15 16:03:51', 3),
(5, 1, 'mk_group', 'Создание групп пользовательских привилегий', '001', 'on', 0, '2008-08-15 16:03:14', '2008-08-15 16:04:54', 3),
(6, 1, 'ls_group', 'Просмотр групп пользовательских привилегий', '001', 'on', 0, '2008-08-15 16:03:14', '2008-08-15 16:05:45', 3),
(7, 1, 'rm_group', 'Удаление групп пользовательских привилегий', '001', 'on', 0, '2008-08-15 16:03:14', '2008-08-15 16:06:01', 3),
(8, 1, 'edit_group', 'Редактирование групп пользовательских привилегий', '001', 'on', 0, '2008-08-15 16:03:14', '2008-08-15 16:06:24', 3),
(9, 1, 'edit_user_privilages', 'Редактирование пользовательских привилегий, групп', '001', 'on', 0, '2008-08-15 16:03:14', '2008-08-15 16:07:12', 3),
(10, 2, 'edit_my_data', 'изменение своей учётной записи', '001', 'on', 0, '2008-08-22 15:31:41', '2008-08-22 15:31:45', 3);

-- --------------------------------------------------------

--
-- Структура таблицы `tbl_nista_simple_gallery`
--

CREATE TABLE IF NOT EXISTS `tbl_nista_simple_gallery` (
  `sgid` int(10) unsigned NOT NULL auto_increment,
  `sg_owner_id` int(10) unsigned default NULL,
  `title` text,
  `text` text,
  `img_way` text,
  `type` varchar(7) default NULL,
  `status` varchar(4) default NULL,
  `meta_keywords` text,
  `date_created` datetime default NULL,
  `timestmp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `creator_uid` int(10) unsigned default NULL,
  `access_level` int(1) unsigned default NULL,
  `pen_name` varchar(255) default NULL,
  `change_times` int(3) unsigned default NULL,
  `show_title` char(1) default NULL,
  `show_text` char(1) default NULL,
  `show_rating` char(1) default NULL,
  `show_pen_name` char(1) default NULL,
  `img_on_page` int(3) unsigned default NULL,
  `img_heght_width` varchar(11) default NULL,
  `sequence` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`sgid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=125 ;

--
-- Дамп данных таблицы `tbl_nista_simple_gallery`
--


-- --------------------------------------------------------

--
-- Структура таблицы `tbl_nista_users`
--

CREATE TABLE IF NOT EXISTS `tbl_nista_users` (
  `uid` int(10) unsigned NOT NULL auto_increment,
  `login` varchar(30) NOT NULL default '',
  `passwd` varchar(40) NOT NULL,
  `surname` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `patronymic` varchar(255) NOT NULL default '',
  `phone` varchar(255) default NULL,
  `icq` int(9) default NULL,
  `email` varchar(255) NOT NULL default '',
  `post` varchar(1) NOT NULL default '0',
  `description` text NOT NULL,
  `date_created` datetime NOT NULL default '0000-00-00 00:00:00',
  `creator_uid` int(10) unsigned NOT NULL default '0',
  `last_back_action_at` datetime NOT NULL,
  `last_front_action_at` datetime NOT NULL,
  `workplace` text NOT NULL,
  `back_login_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `front_login_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `back_ip` varchar(15) NOT NULL default '0.0.0.0',
  `front_ip` varchar(15) NOT NULL default '0.0.0.0',
  `back_status` varchar(5) NOT NULL default 'off',
  `front_status` varchar(5) NOT NULL default 'wait',
  `last_front_login_attempt` datetime NOT NULL default '0000-00-00 00:00:00',
  `front_login` varchar(5) NOT NULL default '0' COMMENT 'max 3 then block',
  `last_back_login_attempt` datetime NOT NULL default '0000-00-00 00:00:00',
  `back_login` varchar(5) NOT NULL default '0' COMMENT 'max 3 then block',
  `front_privilages` text NOT NULL,
  `back_privilages` text NOT NULL,
  `back_secret_code` varchar(32) NOT NULL,
  `front_secret_code` varchar(32) NOT NULL,
  PRIMARY KEY  (`uid`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `login_2` (`login`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Дамп данных таблицы `tbl_nista_users`
--

INSERT INTO `tbl_nista_users` (`uid`, `login`, `passwd`, `surname`, `name`, `patronymic`, `phone`, `icq`, `email`, `post`, `description`, `date_created`, `creator_uid`, `last_back_action_at`, `last_front_action_at`, `workplace`, `back_login_time`, `front_login_time`, `back_ip`, `front_ip`, `back_status`, `front_status`, `last_front_login_attempt`, `front_login`, `last_back_login_attempt`, `back_login`, `front_privilages`, `back_privilages`, `back_secret_code`, `front_secret_code`) VALUES
(3, 'root', 'c87a8ca60f0891b79d192fa86f019916', '', '', '', NULL, NULL, '', '7', '', '0000-00-00 00:00:00', 0, '2009-08-18 18:40:40', '0000-00-00 00:00:00', '', '2009-08-18 18:17:30', '0000-00-00 00:00:00', '127.0.0.1', '127.0.0.1', 'activ', 'wait', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '', '', 'edab08f7428dc765a400d559d16d43a6', '');
